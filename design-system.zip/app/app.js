/**
 * Job Notification Tracker — Dashboard, saved jobs, filter bar, modal, preferences, match scoring.
 */

(function () {
  var STORAGE_KEY = "jnt-saved";
  var PREFERENCES_KEY = "jobTrackerPreferences";
  var STATUS_KEY = "jobTrackerStatus";
  var STATUS_LOG_KEY = "jobTrackerStatusLog";
  var PROOF_KEY = "jobTrackerProofArtifacts";
  var CHECKLIST_KEY = "jobTrackerChecklist";
  var main = document.getElementById("jnt-main");
  var nav = document.getElementById("jnt-nav");
  var navToggle = document.getElementById("jnt-nav-toggle");
  var modal = document.getElementById("jnt-modal");
  var modalBody = document.getElementById("jnt-modal-body");
  var modalClose = document.getElementById("jnt-modal-close");
  var modalBackdrop = document.getElementById("jnt-modal-backdrop");
  var jobs = window.JNT_JOBS || [];

  function getRoute() {
    var hash = window.location.hash.slice(1).replace(/^\/+|\/+$/g, "") || "";
    return hash || "";
  }

  function setActiveLink(route) {
    var links = document.querySelectorAll(".jnt-nav__link");
    links.forEach(function (link) {
      link.classList.toggle("is-active", link.getAttribute("data-route") === route);
    });
  }

  function getSavedIds() {
    try {
      return JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
    } catch (_) {
      return [];
    }
  }

  function saveJob(id) {
    var ids = getSavedIds();
    if (ids.indexOf(id) === -1) ids.push(id);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(ids));
  }

  function unsaveJob(id) {
    var ids = getSavedIds().filter(function (x) { return x !== id; });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(ids));
  }

  function getPreferences() {
    try {
      return JSON.parse(localStorage.getItem(PREFERENCES_KEY) || "{}");
    } catch (_) {
      return {};
    }
  }

  function savePreferences(prefs) {
    localStorage.setItem(PREFERENCES_KEY, JSON.stringify(prefs));
  }

  function getStatusMap() {
    try {
      var raw = localStorage.getItem(STATUS_KEY);
      return raw ? JSON.parse(raw) : {};
    } catch (_) {
      return {};
    }
  }

  function setStatusMap(map) {
    localStorage.setItem(STATUS_KEY, JSON.stringify(map));
  }

  function getStatusLog() {
    try {
      var raw = localStorage.getItem(STATUS_LOG_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch (_) {
      return [];
    }
  }

  function pushStatusLog(entry) {
    var log = getStatusLog();
    log.push(entry);
    localStorage.setItem(STATUS_LOG_KEY, JSON.stringify(log));
  }

  function getJobStatus(id) {
    var map = getStatusMap();
    return map[id] || "Not Applied";
  }

  function setJobStatus(id, status) {
    var map = getStatusMap();
    map[id] = status;
    setStatusMap(map);
    pushStatusLog({ id: id, status: status, ts: new Date().toISOString() });
  }

  function showToast(message) {
    var existing = document.getElementById("jnt-toast");
    if (existing) existing.remove();
    var div = document.createElement("div");
    div.id = "jnt-toast";
    div.className = "jnt-toast";
    div.textContent = message;
    document.body.appendChild(div);
    setTimeout(function () { div.classList.add("is-visible"); }, 10);
    setTimeout(function () {
      div.classList.remove("is-visible");
      setTimeout(function () { if (div.parentNode) div.parentNode.removeChild(div); }, 300);
    }, 1800);
  }

  function getChecklistMap() {
    try {
      var raw = localStorage.getItem(CHECKLIST_KEY);
      return raw ? JSON.parse(raw) : {};
    } catch (_) {
      return {};
    }
  }

  function setChecklistMap(map) {
    localStorage.setItem(CHECKLIST_KEY, JSON.stringify(map));
  }

  function getChecklistItems() {
    return [
      { id: "prefs_persist", label: "Preferences persist after refresh", tip: "Set preferences, refresh page, ensure values remain." },
      { id: "match_score", label: "Match score calculates correctly", tip: "Set keywords/skills and confirm badge reflects changes." },
      { id: "matches_toggle", label: "\"Show only matches\" toggle works", tip: "Enable toggle and confirm low-score jobs hide." },
      { id: "save_persist", label: "Save job persists after refresh", tip: "Save a job, refresh, confirm it remains saved." },
      { id: "apply_new_tab", label: "Apply opens in new tab", tip: "Click Apply and confirm a new tab is opened." },
      { id: "status_persist", label: "Status update persists after refresh", tip: "Change status, refresh, confirm badge and buttons persist." },
      { id: "status_filter", label: "Status filter works correctly", tip: "Filter by a status and verify results match." },
      { id: "digest_top10", label: "Digest generates top 10 by score", tip: "Generate digest; ensure items are score-ordered." },
      { id: "digest_persist", label: "Digest persists for the day", tip: "Refresh Digest; same items appear for current date." },
      { id: "no_console_errors", label: "No console errors on main pages", tip: "Open DevTools and navigate; no errors logged." }
    ];
  }

  function isAllTestsPassed() {
    var items = getChecklistItems();
    var map = getChecklistMap();
    return items.every(function (it) { return !!map[it.id]; });
  }

  function getProofArtifacts() {
    try {
      var raw = localStorage.getItem(PROOF_KEY);
      return raw ? JSON.parse(raw) : { lovable: "", github: "", live: "" };
    } catch (_) {
      return { lovable: "", github: "", live: "" };
    }
  }

  function setProofArtifacts(obj) {
    localStorage.setItem(PROOF_KEY, JSON.stringify(obj));
  }

  function isValidUrl(str) {
    return /^https?:\/\/[^\s]+$/i.test(str || "");
  }

  function calculateMatchScore(job, prefs) {
    if (!prefs || Object.keys(prefs).length === 0) return 0;
    var score = 0;
    var roleKeywords = (prefs.roleKeywords || "").trim().toLowerCase();
    var preferredLocations = prefs.preferredLocations || [];
    var preferredMode = prefs.preferredMode || [];
    var experienceLevel = (prefs.experienceLevel || "").trim();
    var userSkills = (prefs.skills || "").trim().toLowerCase();

    if (roleKeywords) {
      var keywords = roleKeywords.split(",").map(function (k) { return k.trim(); }).filter(Boolean);
      var jobTitleLower = (job.title || "").toLowerCase();
      var jobDescLower = (job.description || "").toLowerCase();
      var titleMatch = keywords.some(function (kw) { return kw && jobTitleLower.indexOf(kw) !== -1; });
      var descMatch = keywords.some(function (kw) { return kw && jobDescLower.indexOf(kw) !== -1; });
      if (titleMatch) score += 25;
      if (descMatch) score += 15;
    }

    if (preferredLocations.length > 0 && preferredLocations.indexOf(job.location) !== -1) {
      score += 15;
    }

    if (preferredMode.length > 0 && preferredMode.indexOf(job.mode) !== -1) {
      score += 10;
    }

    if (experienceLevel && job.experience === experienceLevel) {
      score += 10;
    }

    if (userSkills && job.skills && Array.isArray(job.skills)) {
      var userSkillsList = userSkills.split(",").map(function (s) { return s.trim().toLowerCase(); }).filter(Boolean);
      var hasMatch = job.skills.some(function (js) {
        return userSkillsList.some(function (us) {
          return (js || "").toLowerCase().indexOf(us) !== -1 || us.indexOf((js || "").toLowerCase()) !== -1;
        });
      });
      if (hasMatch) score += 15;
    }

    if (job.postedDaysAgo <= 2) {
      score += 5;
    }

    if (job.source === "LinkedIn") {
      score += 5;
    }

    return Math.min(score, 100);
  }

  function getMatchScoreClass(score) {
    if (score >= 80) return "jnt-badge--match-high";
    if (score >= 60) return "jnt-badge--match-medium";
    if (score >= 40) return "jnt-badge--match-low";
    return "jnt-badge--match-none";
  }

  function formatPosted(days) {
    if (days === 0) return "Today";
    if (days === 1) return "1 day ago";
    return days + " days ago";
  }

  function getFilteredJobs(jobList, opts, prefs) {
    var keyword = (opts.keyword || "").trim().toLowerCase();
    var location = (opts.location || "").trim();
    var mode = (opts.mode || "").trim();
    var experience = (opts.experience || "").trim();
    var source = (opts.source || "").trim();
    var statusFilter = (opts.status || "").trim();
    var showOnlyMatches = opts.showOnlyMatches || false;
    var minMatchScore = (prefs && prefs.minMatchScore !== undefined) ? prefs.minMatchScore : 40;

    var out = jobList.map(function (j) {
      var jobWithScore = Object.assign({}, j);
      jobWithScore.matchScore = calculateMatchScore(j, prefs);
      return jobWithScore;
    });

    out = out.filter(function (j) {
      if (statusFilter && statusFilter !== "All") {
        var s = getJobStatus(j.id);
        if (s !== statusFilter) return false;
      }
      if (keyword && j.title.toLowerCase().indexOf(keyword) === -1 && j.company.toLowerCase().indexOf(keyword) === -1) return false;
      if (location && j.location !== location) return false;
      if (mode && j.mode !== mode) return false;
      if (experience && j.experience !== experience) return false;
      if (source && j.source !== source) return false;
      if (showOnlyMatches && j.matchScore < minMatchScore) return false;
      return true;
    });

    var sort = opts.sort || "latest";
    if (sort === "latest") {
      out = out.slice().sort(function (a, b) { return a.postedDaysAgo - b.postedDaysAgo; });
    } else if (sort === "match") {
      out = out.slice().sort(function (a, b) { return b.matchScore - a.matchScore; });
    } else if (sort === "salary") {
      out = out.slice().sort(function (a, b) {
        var extractNum = function (str) {
          var match = str.match(/(\d+)/);
          return match ? parseInt(match[1], 10) : 0;
        };
        return extractNum(b.salaryRange) - extractNum(a.salaryRange);
      });
    }

    return out;
  }

  function getFilterState() {
    var kw = document.getElementById("jnt-filter-keyword");
    var loc = document.getElementById("jnt-filter-location");
    var md = document.getElementById("jnt-filter-mode");
    var exp = document.getElementById("jnt-filter-experience");
    var src = document.getElementById("jnt-filter-source");
    var srt = document.getElementById("jnt-filter-sort");
    var st = document.getElementById("jnt-filter-status");
    var toggle = document.getElementById("jnt-filter-matches-only");
    return {
      keyword: kw ? kw.value : "",
      location: loc ? loc.value : "",
      mode: md ? md.value : "",
      experience: exp ? exp.value : "",
      source: src ? src.value : "",
      sort: srt ? srt.value : "latest",
      status: st ? st.value : "",
      showOnlyMatches: toggle ? toggle.checked : false
    };
  }

  function jobCard(job, options) {
    var saved = options && options.saved;
    var showUnsave = options && options.showUnsave;
    var matchScore = job.matchScore !== undefined ? job.matchScore : 0;
    var id = job.id;
    var status = getJobStatus(id);
    var statusClass = (function (s) {
      if (s === "Applied") return "jnt-status--applied";
      if (s === "Rejected") return "jnt-status--rejected";
      if (s === "Selected") return "jnt-status--selected";
      return "jnt-status--neutral";
    })(status);
    var statusButtons =
      '<div class="jnt-status-group" role="group" aria-label="Job status">' +
        ['Not Applied','Applied','Rejected','Selected'].map(function (s) {
          var active = s === status ? ' is-active' : '';
          return '<button type="button" class="kn-btn kn-btn--ghost jnt-status-btn' + active + '" data-action="status" data-status="' + s + '" data-id="' + id + '">' + s + '</button>';
        }).join("") +
      '</div>';
    var matchBadge = matchScore > 0 ? '<span class="jnt-badge jnt-badge--match ' + getMatchScoreClass(matchScore) + '">' + matchScore + '%</span>' : '';
    return (
      '<article class="jnt-card" data-id="' + id + '">' +
        '<div class="jnt-card__header">' +
          '<h3 class="jnt-card__title">' + escapeHtml(job.title) + '</h3>' +
          '<div class="jnt-card__badges">' +
            '<span class="jnt-badge jnt-badge--source">' + escapeHtml(job.source) + '</span>' +
            matchBadge +
            '<span class="jnt-badge jnt-badge--status ' + statusClass + '">' + escapeHtml(status) + '</span>' +
          '</div>' +
        '</div>' +
        '<p class="jnt-card__company">' + escapeHtml(job.company) + '</p>' +
        '<p class="jnt-card__meta">' +
          escapeHtml(job.location) + ' · ' + escapeHtml(job.mode) + ' · ' + escapeHtml(job.experience) +
        '</p>' +
        '<p class="jnt-card__salary">' + escapeHtml(job.salaryRange) + '</p>' +
        '<p class="jnt-card__posted">' + formatPosted(job.postedDaysAgo) + '</p>' +
        statusButtons +
        '<div class="jnt-card__actions">' +
          '<button type="button" class="kn-btn kn-btn--secondary jnt-card__btn" data-action="view" data-id="' + id + '">View</button>' +
          (showUnsave
            ? '<button type="button" class="kn-btn kn-btn--ghost jnt-card__btn" data-action="unsave" data-id="' + id + '">Unsave</button>'
            : '<button type="button" class="kn-btn kn-btn--ghost jnt-card__btn" data-action="save" data-id="' + id + '">' + (saved ? "Saved" : "Save") + '</button>') +
          '<a href="' + escapeAttr(job.applyUrl) + '" target="_blank" rel="noopener" class="kn-btn kn-btn--primary jnt-card__btn">Apply</a>' +
        '</div>' +
      '</article>'
    );
  }

  function escapeHtml(s) {
    if (!s) return "";
    var div = document.createElement("div");
    div.textContent = s;
    return div.innerHTML;
  }

  function escapeAttr(s) {
    if (!s) return "#";
    var div = document.createElement("div");
    div.textContent = s;
    return div.innerHTML.replace(/"/g, "&quot;");
  }

  function openModal(job) {
    modalBody.innerHTML =
      '<p class="jnt-modal__description">' + escapeHtml(job.description) + '</p>' +
      '<p class="jnt-modal__skills-label">Skills</p>' +
      '<p class="jnt-modal__skills">' + (job.skills && job.skills.length ? escapeHtml(job.skills.join(", ")) : "—") + '</p>';
    modal.hidden = false;
    modalClose.focus();
  }

  function closeModal() {
    modal.hidden = true;
  }

  function distinct(values) {
    var seen = {};
    return values.filter(function (v) { return v && !seen[v] && (seen[v] = true); });
  }

  function renderDashboard() {
    var prefs = getPreferences();
    var hasPrefs = prefs && Object.keys(prefs).length > 0 && (prefs.roleKeywords || prefs.preferredLocations || prefs.preferredMode || prefs.experienceLevel || prefs.skills);
    var state = main.querySelector(".jnt-dashboard") ? getFilterState() : { keyword: "", location: "", mode: "", experience: "", source: "", status: "", sort: "latest", showOnlyMatches: false };
    var locations = distinct(jobs.map(function (j) { return j.location; })).sort();
    var savedIds = getSavedIds();
    var filtered = getFilteredJobs(jobs, state, prefs);
    var banner = !hasPrefs ? '<div class="jnt-banner jnt-banner--info"><p>Set your preferences to activate intelligent matching.</p></div>' : '';
    var filterBar =
      '<div class="jnt-filters">' +
        '<input type="text" id="jnt-filter-keyword" class="kn-input jnt-filters__input" placeholder="Search title or company" value="' + escapeAttr(state.keyword) + '" />' +
        '<select id="jnt-filter-location" class="jnt-select jnt-filters__select">' +
          '<option value="">All locations</option>' +
          locations.map(function (loc) { return '<option value="' + escapeAttr(loc) + '"' + (state.location === loc ? ' selected' : '') + '>' + escapeHtml(loc) + '</option>'; }).join("") +
        '</select>' +
        '<select id="jnt-filter-mode" class="jnt-select jnt-filters__select">' +
          '<option value="">All modes</option>' +
          '<option value="Remote"' + (state.mode === "Remote" ? " selected" : "") + '>Remote</option>' +
          '<option value="Hybrid"' + (state.mode === "Hybrid" ? " selected" : "") + '>Hybrid</option>' +
          '<option value="Onsite"' + (state.mode === "Onsite" ? " selected" : "") + '>Onsite</option>' +
        '</select>' +
        '<select id="jnt-filter-experience" class="jnt-select jnt-filters__select">' +
          '<option value="">All experience</option>' +
          '<option value="Fresher"' + (state.experience === "Fresher" ? " selected" : "") + '>Fresher</option>' +
          '<option value="0-1"' + (state.experience === "0-1" ? " selected" : "") + '>0-1</option>' +
          '<option value="1-3"' + (state.experience === "1-3" ? " selected" : "") + '>1-3</option>' +
          '<option value="3-5"' + (state.experience === "3-5" ? " selected" : "") + '>3-5</option>' +
        '</select>' +
        '<select id="jnt-filter-source" class="jnt-select jnt-filters__select">' +
          '<option value="">All sources</option>' +
          '<option value="LinkedIn"' + (state.source === "LinkedIn" ? " selected" : "") + '>LinkedIn</option>' +
          '<option value="Naukri"' + (state.source === "Naukri" ? " selected" : "") + '>Naukri</option>' +
          '<option value="Indeed"' + (state.source === "Indeed" ? " selected" : "") + '>Indeed</option>' +
        '</select>' +
        '<select id="jnt-filter-status" class="jnt-select jnt-filters__select">' +
          '<option value="">All statuses</option>' +
          '<option value="Not Applied"' + (state.status === "Not Applied" ? " selected" : "") + '>Not Applied</option>' +
          '<option value="Applied"' + (state.status === "Applied" ? " selected" : "") + '>Applied</option>' +
          '<option value="Rejected"' + (state.status === "Rejected" ? " selected" : "") + '>Rejected</option>' +
          '<option value="Selected"' + (state.status === "Selected" ? " selected" : "") + '>Selected</option>' +
        '</select>' +
        '<select id="jnt-filter-sort" class="jnt-select jnt-filters__select">' +
          '<option value="latest"' + (state.sort === "latest" ? " selected" : "") + '>Latest</option>' +
          '<option value="match"' + (state.sort === "match" ? " selected" : "") + '>Match Score</option>' +
          '<option value="salary"' + (state.sort === "salary" ? " selected" : "") + '>Salary</option>' +
        '</select>' +
      '</div>';
    var toggle = hasPrefs ? '<div class="jnt-toggle-wrapper"><label class="jnt-toggle"><input type="checkbox" id="jnt-filter-matches-only" ' + (state.showOnlyMatches ? 'checked' : '') + ' /><span>Show only jobs above my threshold</span></label></div>' : '';
    var cardsHtml = filtered.length > 0 ? filtered.map(function (j) { return jobCard(j, { saved: savedIds.indexOf(j.id) !== -1 }); }).join("") : '<div class="jnt-empty"><h2 class="jnt-empty__title">No roles match your criteria.</h2><p class="jnt-empty__text">Adjust filters or lower threshold.</p></div>';
    main.innerHTML =
      '<div class="jnt-dashboard">' +
        '<h1 class="jnt-page-heading">Dashboard</h1>' +
        '<p class="jnt-page-subtext">Browse and filter jobs. Save to revisit later.</p>' +
        banner +
        filterBar +
        toggle +
        '<div id="jnt-job-list" class="jnt-job-list">' + cardsHtml + '</div>' +
      '</div>';
    attachFilterListeners();
  }

  function attachFilterListeners() {
    var keyword = document.getElementById("jnt-filter-keyword");
    var selects = ["jnt-filter-location", "jnt-filter-mode", "jnt-filter-experience", "jnt-filter-source", "jnt-filter-status", "jnt-filter-sort"];
    var toggle = document.getElementById("jnt-filter-matches-only");
    var prefs = getPreferences();
    function updateList() {
      var state = getFilterState();
      var savedIds = getSavedIds();
      var filtered = getFilteredJobs(jobs, state, prefs);
      var listEl = document.getElementById("jnt-job-list");
      if (listEl) {
        if (filtered.length === 0) {
          listEl.innerHTML = '<div class="jnt-empty"><h2 class="jnt-empty__title">No roles match your criteria.</h2><p class="jnt-empty__text">Adjust filters or lower threshold.</p></div>';
        } else {
          listEl.innerHTML = filtered.map(function (j) { return jobCard(j, { saved: savedIds.indexOf(j.id) !== -1 }); }).join("");
        }
      }
    }
    if (keyword) keyword.addEventListener("input", updateList);
    selects.forEach(function (id) {
      var el = document.getElementById(id);
      if (el) el.addEventListener("change", updateList);
    });
    if (toggle) toggle.addEventListener("change", updateList);
  }

  function renderLanding() {
    main.innerHTML =
      '<section class="jnt-landing">' +
        '<h1 class="jnt-landing__headline">Stop Missing The Right Jobs.</h1>' +
        '<p class="jnt-landing__subtext">Precision-matched job discovery delivered daily at 9AM.</p>' +
        '<a href="#/settings" class="kn-btn kn-btn--primary jnt-landing__cta">Start Tracking</a>' +
      '</section>';
  }

  function renderSettings() {
    var prefs = getPreferences();
    var locations = distinct(jobs.map(function (j) { return j.location; })).sort();
    var roleKeywords = (prefs.roleKeywords || "").trim();
    var preferredLocations = prefs.preferredLocations || [];
    var preferredMode = prefs.preferredMode || [];
    var experienceLevel = (prefs.experienceLevel || "").trim();
    var skills = (prefs.skills || "").trim();
    var minMatchScore = prefs.minMatchScore !== undefined ? prefs.minMatchScore : 40;
    var locationOptions = locations.map(function (loc) {
      var selected = preferredLocations.indexOf(loc) !== -1 ? ' selected' : '';
      return '<option value="' + escapeAttr(loc) + '"' + selected + '>' + escapeHtml(loc) + '</option>';
    }).join("");
    main.innerHTML =
      '<div class="jnt-settings">' +
        '<h1 class="jnt-page-heading">Settings</h1>' +
        '<p class="jnt-page-subtext">Configure your job preferences to enable intelligent matching.</p>' +
        '<form class="jnt-settings__form" id="jnt-settings-form" novalidate>' +
          '<div class="jnt-settings__field">' +
            '<label for="jnt-role-keywords" class="kn-label">Role keywords</label>' +
            '<input type="text" id="jnt-role-keywords" class="kn-input" placeholder="e.g. Frontend, React, TypeScript" value="' + escapeAttr(roleKeywords) + '" />' +
            '<p class="jnt-settings__hint">Comma-separated keywords that appear in job titles or descriptions</p>' +
          '</div>' +
          '<div class="jnt-settings__field">' +
            '<label for="jnt-locations" class="kn-label">Preferred locations</label>' +
            '<select id="jnt-locations" class="jnt-select jnt-select--multi" multiple size="5">' +
              locationOptions +
            '</select>' +
            '<p class="jnt-settings__hint">Hold Ctrl/Cmd to select multiple</p>' +
          '</div>' +
          '<div class="jnt-settings__field">' +
            '<label class="kn-label">Preferred mode</label>' +
            '<div class="jnt-checkbox-group">' +
              '<label class="jnt-checkbox"><input type="checkbox" name="jnt-mode" value="Remote" ' + (preferredMode.indexOf("Remote") !== -1 ? 'checked' : '') + ' /><span>Remote</span></label>' +
              '<label class="jnt-checkbox"><input type="checkbox" name="jnt-mode" value="Hybrid" ' + (preferredMode.indexOf("Hybrid") !== -1 ? 'checked' : '') + ' /><span>Hybrid</span></label>' +
              '<label class="jnt-checkbox"><input type="checkbox" name="jnt-mode" value="Onsite" ' + (preferredMode.indexOf("Onsite") !== -1 ? 'checked' : '') + ' /><span>Onsite</span></label>' +
            '</div>' +
          '</div>' +
          '<div class="jnt-settings__field">' +
            '<label for="jnt-experience" class="kn-label">Experience level</label>' +
            '<select id="jnt-experience" class="jnt-select">' +
              '<option value="">Select…</option>' +
              '<option value="Fresher"' + (experienceLevel === "Fresher" ? " selected" : "") + '>Fresher</option>' +
              '<option value="0-1"' + (experienceLevel === "0-1" ? " selected" : "") + '>0-1</option>' +
              '<option value="1-3"' + (experienceLevel === "1-3" ? " selected" : "") + '>1-3</option>' +
              '<option value="3-5"' + (experienceLevel === "3-5" ? " selected" : "") + '>3-5</option>' +
            '</select>' +
          '</div>' +
          '<div class="jnt-settings__field">' +
            '<label for="jnt-skills" class="kn-label">Skills</label>' +
            '<input type="text" id="jnt-skills" class="kn-input" placeholder="e.g. Java, React, Python" value="' + escapeAttr(skills) + '" />' +
            '<p class="jnt-settings__hint">Comma-separated skills to match against job requirements</p>' +
          '</div>' +
          '<div class="jnt-settings__field">' +
            '<label for="jnt-min-match-score" class="kn-label">Minimum match score threshold: <span id="jnt-min-match-score-value">' + minMatchScore + '</span></label>' +
            '<input type="range" id="jnt-min-match-score" class="jnt-slider" min="0" max="100" value="' + minMatchScore + '" />' +
            '<p class="jnt-settings__hint">Jobs below this score will be hidden when "Show only matches" is enabled</p>' +
          '</div>' +
          '<button type="submit" class="kn-btn kn-btn--primary">Save Preferences</button>' +
        '</form>' +
      '</div>';
    attachSettingsListeners();
  }

  function attachSettingsListeners() {
    var form = document.getElementById("jnt-settings-form");
    var slider = document.getElementById("jnt-min-match-score");
    var sliderValue = document.getElementById("jnt-min-match-score-value");
    if (slider && sliderValue) {
      slider.addEventListener("input", function () {
        sliderValue.textContent = slider.value;
      });
    }
    if (form) {
      form.addEventListener("submit", function (e) {
        e.preventDefault();
        var roleKeywords = (document.getElementById("jnt-role-keywords").value || "").trim();
        var locationSelect = document.getElementById("jnt-locations");
        var preferredLocations = Array.from(locationSelect.selectedOptions).map(function (opt) { return opt.value; });
        var modeCheckboxes = document.querySelectorAll('input[name="jnt-mode"]:checked');
        var preferredMode = Array.from(modeCheckboxes).map(function (cb) { return cb.value; });
        var experienceLevel = (document.getElementById("jnt-experience").value || "").trim();
        var skills = (document.getElementById("jnt-skills").value || "").trim();
        var minMatchScore = parseInt(slider.value, 10) || 40;
        var prefs = {
          roleKeywords: roleKeywords,
          preferredLocations: preferredLocations,
          preferredMode: preferredMode,
          experienceLevel: experienceLevel,
          skills: skills,
          minMatchScore: minMatchScore
        };
        savePreferences(prefs);
        if (main.querySelector(".jnt-dashboard")) renderDashboard();
        alert("Preferences saved!");
      });
    }
  }

  function renderSaved() {
    var savedIds = getSavedIds();
    var savedJobs = savedIds.map(function (id) { return jobs.find(function (j) { return j.id === id; }); }).filter(Boolean);
    if (savedJobs.length === 0) {
      main.innerHTML =
        '<div class="jnt-empty">' +
          '<h2 class="jnt-empty__title">No saved jobs</h2>' +
          '<p class="jnt-empty__text">Save jobs from the Dashboard to revisit them here.</p>' +
          '<a href="#/dashboard" class="kn-btn kn-btn--primary jnt-empty__action">Go to Dashboard</a>' +
        '</div>';
      return;
    }
    var cardsHtml = savedJobs.map(function (j) { return jobCard(j, { showUnsave: true }); }).join("");
    main.innerHTML =
      '<div class="jnt-saved">' +
        '<h1 class="jnt-page-heading">Saved</h1>' +
        '<p class="jnt-page-subtext">Jobs you saved for later.</p>' +
        '<div class="jnt-job-list">' + cardsHtml + '</div>' +
      '</div>';
  }

  function renderDigest() {
    var prefs = getPreferences();
    var hasPrefs = prefs && Object.keys(prefs).length > 0 && (prefs.roleKeywords || prefs.preferredLocations || prefs.preferredMode || prefs.experienceLevel || prefs.skills);
    var today = new Date();
    var yyyy = today.getFullYear();
    var mm = String(today.getMonth() + 1).padStart(2, "0");
    var dd = String(today.getDate()).padStart(2, "0");
    var dateStr = yyyy + "-" + mm + "-" + dd;
    var storageKey = "jobTrackerDigest_" + dateStr;
    function getDigestIds() {
      try {
        var raw = localStorage.getItem(storageKey);
        return raw ? JSON.parse(raw) : null;
      } catch (_) {
        return null;
      }
    }
    function buildDigestIds() {
      var scored = jobs.map(function (j) {
        return Object.assign({}, j, { matchScore: calculateMatchScore(j, prefs) });
      });
      var minMatch = (prefs && prefs.minMatchScore !== undefined) ? prefs.minMatchScore : 0;
      var filtered = scored.filter(function (j) { return j.matchScore >= minMatch; });
      filtered.sort(function (a, b) {
        if (b.matchScore !== a.matchScore) return b.matchScore - a.matchScore;
        return a.postedDaysAgo - b.postedDaysAgo;
      });
      var top = filtered.slice(0, 10).map(function (j) { return j.id; });
      return top;
    }
    function jobsFromIds(ids) {
      return ids.map(function (id) {
        var j = jobs.find(function (x) { return x.id === id; });
        if (!j) return null;
        var m = calculateMatchScore(j, prefs);
        return Object.assign({}, j, { matchScore: m });
      }).filter(Boolean);
    }
    function buildDigestText(dateLabel, items) {
      var lines = [];
      lines.push("Top 10 Jobs For You — 9AM Digest");
      lines.push(dateLabel);
      lines.push("");
      items.forEach(function (j, idx) {
        var line = (idx + 1) + ". " + j.title + " — " + j.company + " — " + j.location + " — " + j.experience + " — Match " + (j.matchScore || 0) + "%";
        lines.push(line);
        lines.push("Apply: " + j.applyUrl);
      });
      lines.push("");
      lines.push("This digest was generated based on your preferences.");
      return lines.join("\n");
    }
    function renderState(digestIds) {
      var dateLabel = today.toLocaleDateString(undefined, { year: "numeric", month: "long", day: "numeric" });
      if (!hasPrefs) {
        main.innerHTML =
          '<div class="jnt-digest">' +
            '<div class="jnt-digest__note">Demo Mode: Daily 9AM trigger simulated manually.</div>' +
            '<div class="jnt-digest__card">' +
              '<h1 class="jnt-digest__title">Top 10 Jobs For You — 9AM Digest</h1>' +
              '<p class="jnt-digest__date">' + escapeHtml(dateLabel) + '</p>' +
              '<div class="jnt-digest__blocker">Set preferences to generate a personalized digest.</div>' +
              '<button type="button" class="kn-btn kn-btn--primary jnt-digest__generate" id="jnt-digest-generate" disabled>Generate Today\'s 9AM Digest (Simulated)</button>' +
            '</div>' +
          '</div>';
        return;
      }
      if (!digestIds || digestIds.length === 0) {
        main.innerHTML =
          '<div class="jnt-digest">' +
            '<div class="jnt-digest__note">Demo Mode: Daily 9AM trigger simulated manually.</div>' +
            '<div class="jnt-digest__card">' +
              '<h1 class="jnt-digest__title">Top 10 Jobs For You — 9AM Digest</h1>' +
              '<p class="jnt-digest__date">' + escapeHtml(dateLabel) + '</p>' +
              '<p class="jnt-digest__empty">No matching roles today. Check again tomorrow.</p>' +
              '<button type="button" class="kn-btn kn-btn--primary jnt-digest__generate" id="jnt-digest-generate">Generate Today\'s 9AM Digest (Simulated)</button>' +
            '</div>' +
          '</div>';
        attachDigestListeners();
        return;
      }
      var digestJobs = jobsFromIds(digestIds);
      if (digestJobs.length === 0) {
        main.innerHTML =
          '<div class="jnt-digest">' +
            '<div class="jnt-digest__note">Demo Mode: Daily 9AM trigger simulated manually.</div>' +
            '<div class="jnt-digest__card">' +
              '<h1 class="jnt-digest__title">Top 10 Jobs For You — 9AM Digest</h1>' +
              '<p class="jnt-digest__date">' + escapeHtml(dateLabel) + '</p>' +
              '<p class="jnt-digest__empty">No matching roles today. Check again tomorrow.</p>' +
              '<button type="button" class="kn-btn kn-btn--primary jnt-digest__generate" id="jnt-digest-generate">Generate Today\'s 9AM Digest (Simulated)</button>' +
            '</div>' +
          '</div>';
        attachDigestListeners();
        return;
      }
      var itemsHtml = digestJobs.map(function (j) {
        var cls = 'jnt-badge jnt-badge--match ' + getMatchScoreClass(j.matchScore || 0);
        return (
          '<div class="jnt-digest__item">' +
            '<div class="jnt-digest__item-main">' +
              '<h3 class="jnt-digest__job-title">' + escapeHtml(j.title) + '</h3>' +
              '<p class="jnt-digest__job-meta">' + escapeHtml(j.company) + ' · ' + escapeHtml(j.location) + ' · ' + escapeHtml(j.experience) + '</p>' +
            '</div>' +
            '<div class="jnt-digest__item-side">' +
              '<span class="' + cls + '">' + (j.matchScore || 0) + '%</span>' +
              '<a class="kn-btn kn-btn--secondary jnt-digest__apply" href="' + escapeAttr(j.applyUrl) + '" target="_blank" rel="noopener">Apply</a>' +
            '</div>' +
          '</div>'
        );
      }).join("");
      var text = buildDigestText(dateLabel, digestJobs);
      var statusLog = getStatusLog().slice().sort(function (a, b) { return new Date(b.ts) - new Date(a.ts); }).slice(0, 10);
      var statusHtml = statusLog.length > 0 ? statusLog.map(function (entry) {
        var j = jobs.find(function (x) { return x.id === entry.id; });
        if (!j) return '';
        var d = new Date(entry.ts);
        var line = '<div class="jnt-digest__item"><div class="jnt-digest__item-main"><h3 class="jnt-digest__job-title">' + escapeHtml(j.title) + '</h3><p class="jnt-digest__job-meta">' + escapeHtml(j.company) + '</p></div><div class="jnt-digest__item-side"><span class="jnt-badge jnt-badge--status ' + (entry.status === 'Applied' ? 'jnt-status--applied' : entry.status === 'Rejected' ? 'jnt-status--rejected' : entry.status === 'Selected' ? 'jnt-status--selected' : 'jnt-status--neutral') + '">' + escapeHtml(entry.status) + '</span><span class="jnt-digest__date">' + escapeHtml(d.toLocaleString()) + '</span></div></div>';
        return line;
      }).join("") : '<p class="jnt-digest__empty">No recent updates.</p>';
      main.innerHTML =
        '<div class="jnt-digest">' +
          '<div class="jnt-digest__note">Demo Mode: Daily 9AM trigger simulated manually.</div>' +
          '<div class="jnt-digest__card">' +
            '<div class="jnt-digest__header">' +
              '<h1 class="jnt-digest__title">Top 10 Jobs For You — 9AM Digest</h1>' +
              '<p class="jnt-digest__date">' + escapeHtml(dateLabel) + '</p>' +
            '</div>' +
            '<div class="jnt-digest__actions">' +
              '<button type="button" class="kn-btn kn-btn--secondary" id="jnt-digest-copy">Copy Digest to Clipboard</button>' +
              '<a href="#" class="kn-btn kn-btn--primary" id="jnt-digest-email">Create Email Draft</a>' +
            '</div>' +
            '<div class="jnt-digest__list">' + itemsHtml + '</div>' +
            '<p class="jnt-digest__footer">This digest was generated based on your preferences.</p>' +
          '</div>' +
          '<div class="jnt-digest__card" style="margin-top: var(--kn-space-2)">' +
            '<div class="jnt-digest__header">' +
              '<h1 class="jnt-digest__title">Recent Status Updates</h1>' +
            '</div>' +
            '<div class="jnt-digest__list">' + statusHtml + '</div>' +
          '</div>' +
          '<textarea id="jnt-digest-text" style="position:absolute;left:-9999px;top:-9999px" aria-hidden="true">' + escapeHtml(text) + '</textarea>' +
        '</div>';
      attachDigestListeners();
    }
    function attachDigestListeners() {
      var gen = document.getElementById("jnt-digest-generate");
      if (gen) {
        gen.addEventListener("click", function () {
          var existing = getDigestIds();
          if (existing && existing.length > 0) {
            renderState(existing);
            return;
          }
          var built = buildDigestIds();
          localStorage.setItem(storageKey, JSON.stringify(built));
          renderState(built);
        });
      }
      var copyBtn = document.getElementById("jnt-digest-copy");
      if (copyBtn) {
        copyBtn.addEventListener("click", function (e) {
          e.preventDefault();
          var hidden = document.getElementById("jnt-digest-text");
          if (hidden) {
            var text = hidden.value || hidden.textContent || "";
            if (navigator.clipboard && navigator.clipboard.writeText) {
              navigator.clipboard.writeText(text).then(function () {
                copyBtn.textContent = "Copied";
                setTimeout(function () { copyBtn.textContent = "Copy Digest to Clipboard"; }, 1500);
              });
            } else {
              hidden.style.display = "block";
              hidden.select();
              document.execCommand("copy");
              hidden.style.display = "none";
            }
          }
        });
      }
      var emailBtn = document.getElementById("jnt-digest-email");
      if (emailBtn) {
        emailBtn.addEventListener("click", function (e) {
          e.preventDefault();
          var hidden = document.getElementById("jnt-digest-text");
          var text = hidden ? (hidden.value || hidden.textContent || "") : "";
          var subject = encodeURIComponent("My 9AM Job Digest");
          var body = encodeURIComponent(text);
          var href = "mailto:?subject=" + subject + "&body=" + body;
          emailBtn.setAttribute("href", href);
          window.location.href = href;
        });
      }
    }
    var existing = getDigestIds();
    renderState(existing);
  }

  function renderProof() {
    main.innerHTML =
      '<div class="jnt-proof">' +
        '<h1 class="jnt-page-heading">Proof</h1>' +
        '<p class="jnt-page-subtext">Placeholder for artifact collection.</p>' +
      '</div>';
  }

  function render(route) {
    setActiveLink(route);
    switch (route) {
      case "":
        renderLanding();
        break;
      case "settings":
        renderSettings();
        break;
      case "dashboard":
        renderDashboard();
        break;
      case "saved":
        renderSaved();
        break;
      case "digest":
        renderDigest();
        break;
      case "proof":
        renderProof();
        break;
      case "jt/07-test":
        renderJT07Test();
        break;
      case "jt/08-ship":
        renderJT08Ship();
        break;
      case "jt/proof":
        renderJTProof();
        break;
      default:
        renderLanding();
    }
  }

  function renderJT07Test() {
    var items = getChecklistItems();
    var map = getChecklistMap();
    var passed = items.filter(function (it) { return !!map[it.id]; }).length;
    var total = items.length;
    var listHtml = items.map(function (it) {
      var checked = map[it.id] ? ' checked' : '';
      var tip = it.tip ? '<span class="jnt-test__hint" title="' + escapeAttr(it.tip) + '">?</span>' : '';
      return '<label class="jnt-test__item"><input type="checkbox" class="jnt-test__checkbox" data-test-id="' + it.id + '"' + checked + ' />' + '<span class="jnt-test__label">' + escapeHtml(it.label) + '</span>' + tip + '</label>';
    }).join("");
    var warning = passed < total ? '<p class="jnt-test__warning">Resolve all issues before shipping.</p>' : '';
    main.innerHTML =
      '<div class="jnt-test">' +
        '<div class="jnt-test__card">' +
          '<h1 class="jnt-page-heading">Built-In Test Checklist</h1>' +
          '<p class="jnt-page-subtext">Use this checklist to ensure quality before shipping.</p>' +
          '<div class="jnt-test__summary"><strong>Tests Passed: <span id="jnt-test-count">' + passed + '</span> / ' + total + '</strong></div>' +
          warning +
          '<div class="jnt-test__list">' + listHtml + '</div>' +
          '<div class="jnt-test__actions"><button type="button" class="kn-btn kn-btn--secondary" id="jnt-test-reset">Reset Test Status</button></div>' +
        '</div>' +
      '</div>';
    var checkboxes = main.querySelectorAll(".jnt-test__checkbox");
    checkboxes.forEach(function (cb) {
      cb.addEventListener("change", function () {
        var id = cb.getAttribute("data-test-id");
        var m = getChecklistMap();
        m[id] = cb.checked;
        setChecklistMap(m);
        var cnt = items.filter(function (it) { return !!m[it.id]; }).length;
        var cntEl = document.getElementById("jnt-test-count");
        if (cntEl) cntEl.textContent = String(cnt);
        var warnEl = main.querySelector(".jnt-test__warning");
        if (warnEl) {
          if (cnt === total) warnEl.remove();
        } else {
          if (cnt < total) {
            var p = document.createElement("p");
            p.className = "jnt-test__warning";
            p.textContent = "Resolve all issues before shipping.";
            var card = main.querySelector(".jnt-test__card");
            if (card) card.insertBefore(p, card.querySelector(".jnt-test__list"));
          }
        }
      });
    });
    var reset = document.getElementById("jnt-test-reset");
    if (reset) {
      reset.addEventListener("click", function () {
        localStorage.removeItem(CHECKLIST_KEY);
        renderJT07Test();
      });
    }
  }

  function renderJT08Ship() {
    var locked = !isAllTestsPassed();
    if (locked) {
      main.innerHTML =
        '<div class="jnt-test">' +
          '<div class="jnt-test__card">' +
            '<h1 class="jnt-page-heading">Ship</h1>' +
            '<p class="jnt-page-subtext">Locked until all checklist items are passed.</p>' +
            '<p class="jnt-test__warning">Resolve all issues before shipping.</p>' +
            '<a href="#/jt/07-test" class="kn-btn kn-btn--primary">Open Checklist</a>' +
          '</div>' +
        '</div>';
      return;
    }
    main.innerHTML =
      '<div class="jnt-test">' +
        '<div class="jnt-test__card">' +
          '<h1 class="jnt-page-heading">Ship</h1>' +
          '<p class="jnt-page-subtext">All tests passed. Ready to ship.</p>' +
        '</div>' +
      '</div>';
  }

  function renderJTProof() {
    var items = getChecklistItems();
    var map = getChecklistMap();
    var selectedIds = ["prefs_persist","match_score","matches_toggle","save_persist","apply_new_tab","status_persist","status_filter","digest_persist"];
    var rows = selectedIds.map(function (id) {
      var item = items.find(function (x) { return x.id === id; });
      var done = !!map[id];
      var badge = '<span class="jnt-badge jnt-badge--status ' + (done ? 'jnt-status--selected' : 'jnt-status--neutral') + '">' + (done ? 'Completed' : 'Pending') + '</span>';
      return '<div class="jnt-proof__row"><span>' + (item ? escapeHtml(item.label) : escapeHtml(id)) + '</span>' + badge + '</div>';
    }).join("");
    var art = getProofArtifacts();
    var linksProvided = isValidUrl(art.lovable) && isValidUrl(art.github) && isValidUrl(art.live);
    var allPassed = isAllTestsPassed();
    var shipped = linksProvided && allPassed;
    var statusText = shipped ? "Shipped" : (linksProvided || Object.keys(map).some(function (k) { return map[k]; }) ? "In Progress" : "Not Started");
    var statusClass = shipped ? "jnt-badge--ship jnt-badge--ship-ok" : (statusText === "In Progress" ? "jnt-badge--ship jnt-badge--ship-progress" : "jnt-badge--ship jnt-badge--ship-neutral");
    main.innerHTML =
      '<div class="jnt-proof">' +
        '<div class="jnt-proof__card">' +
          '<div class="jnt-proof__header">' +
            '<h1 class="jnt-page-heading">Project 1 — Job Notification Tracker</h1>' +
            '<div class="jnt-proof__status"><span class="' + statusClass + '">' + statusText + '</span></div>' +
            (shipped ? '<p class="jnt-proof__success">Project 1 Shipped Successfully.</p>' : '') +
          '</div>' +
          '<h2 class="jnt-proof__title">Step Completion Summary</h2>' +
          '<div class="jnt-proof__list">' + rows + '</div>' +
        '</div>' +
        '<div class="jnt-proof__card">' +
          '<h2 class="jnt-proof__title">Artifact Collection</h2>' +
          '<div class="jnt-proof__form">' +
            '<label class="jnt-proof__field"><span class="kn-label">Lovable Project Link</span>' +
              '<input type="url" class="kn-input" id="jnt-proof-lovable" placeholder="https://..." value="' + escapeAttr(art.lovable) + '"/>' +
              '<small class="jnt-proof__error" id="jnt-proof-err-lovable"></small>' +
            '</label>' +
            '<label class="jnt-proof__field"><span class="kn-label">GitHub Repository Link</span>' +
              '<input type="url" class="kn-input" id="jnt-proof-github" placeholder="https://..." value="' + escapeAttr(art.github) + '"/>' +
              '<small class="jnt-proof__error" id="jnt-proof-err-github"></small>' +
            '</label>' +
            '<label class="jnt-proof__field"><span class="kn-label">Deployed URL</span>' +
              '<input type="url" class="kn-input" id="jnt-proof-live" placeholder="https://..." value="' + escapeAttr(art.live) + '"/>' +
              '<small class="jnt-proof__error" id="jnt-proof-err-live"></small>' +
            '</label>' +
            '<div class="jnt-proof__actions">' +
              '<button type="button" class="kn-btn kn-btn--secondary" id="jnt-proof-copy">Copy Final Submission</button>' +
            '</div>' +
          '</div>' +
        '</div>' +
        '<textarea id="jnt-proof-text" style="position:absolute;left:-9999px;top:-9999px" aria-hidden="true"></textarea>' +
      '</div>';
    attachProofListeners();
  }

  function attachProofListeners() {
    var inputs = [
      { id: "jnt-proof-lovable", key: "lovable", err: "jnt-proof-err-lovable" },
      { id: "jnt-proof-github", key: "github", err: "jnt-proof-err-github" },
      { id: "jnt-proof-live", key: "live", err: "jnt-proof-err-live" }
    ];
    inputs.forEach(function (cfg) {
      var el = document.getElementById(cfg.id);
      if (!el) return;
      var errEl = document.getElementById(cfg.err);
      var validateAndSave = function () {
        var value = (el.value || "").trim();
        var art = getProofArtifacts();
        art[cfg.key] = value;
        setProofArtifacts(art);
        if (value && !isValidUrl(value)) {
          if (errEl) errEl.textContent = "Enter a valid URL (http/https).";
        } else {
          if (errEl) errEl.textContent = "";
        }
        renderJTProof();
      };
      el.addEventListener("blur", validateAndSave);
      el.addEventListener("change", validateAndSave);
    });
    var copyBtn = document.getElementById("jnt-proof-copy");
    if (copyBtn) {
      copyBtn.addEventListener("click", function () {
        var art = getProofArtifacts();
        var text = [
          "------------------------------------------",
          "Job Notification Tracker — Final Submission",
          "",
          "Lovable Project:",
          art.lovable || "",
          "",
          "GitHub Repository:",
          art.github || "",
          "",
          "Live Deployment:",
          art.live || "",
          "",
          "Core Features:",
          "- Intelligent match scoring",
          "- Daily digest simulation",
          "- Status tracking",
          "- Test checklist enforced",
          "------------------------------------------"
        ].join("\n");
        var hidden = document.getElementById("jnt-proof-text");
        if (hidden) {
          hidden.value = text;
          if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text).then(function () {
              showToast("Submission copied");
            });
          } else {
            hidden.style.display = "block";
            hidden.select();
            document.execCommand("copy");
            hidden.style.display = "none";
            showToast("Submission copied");
          }
        }
      });
    }
  }
  main.addEventListener("click", function (e) {
    var btn = e.target.closest("[data-action][data-id]");
    if (!btn) return;
    var action = btn.getAttribute("data-action");
    var id = btn.getAttribute("data-id");
    var job = jobs.filter(function (j) { return j.id === id; })[0];
    if (action === "view" && job) {
      e.preventDefault();
      openModal(job);
    } else if (action === "save" && job) {
      e.preventDefault();
      saveJob(id);
      if (main.querySelector(".jnt-dashboard")) {
        var prefs = getPreferences();
        attachFilterListeners();
        var list = document.getElementById("jnt-job-list");
        if (list) {
          var savedIds = getSavedIds();
          var state = getFilterState();
          var filtered = getFilteredJobs(jobs, state, prefs);
          if (filtered.length === 0) {
            list.innerHTML = '<div class="jnt-empty"><h2 class="jnt-empty__title">No roles match your criteria.</h2><p class="jnt-empty__text">Adjust filters or lower threshold.</p></div>';
          } else {
            list.innerHTML = filtered.map(function (j) {
              return jobCard(j, { saved: savedIds.indexOf(j.id) !== -1, showUnsave: !!main.querySelector(".jnt-saved") });
            }).join("");
          }
        }
      } else {
        var list = document.getElementById("jnt-job-list");
        if (list) {
          var savedIds = getSavedIds();
          var savedJobs = jobs.filter(function (j) { return savedIds.indexOf(j.id) !== -1; });
          list.innerHTML = savedJobs.map(function (j) {
            return jobCard(j, { saved: true, showUnsave: true });
          }).join("");
        }
      }
      btn.textContent = "Saved";
    } else if (action === "status" && job) {
      e.preventDefault();
      var newStatus = btn.getAttribute("data-status");
      setJobStatus(id, newStatus);
      if (newStatus === "Applied" || newStatus === "Rejected" || newStatus === "Selected") {
        showToast("Status updated: " + newStatus);
      }
      if (main.querySelector(".jnt-dashboard")) {
        renderDashboard();
      } else if (main.querySelector(".jnt-saved")) {
        renderSaved();
      } else if (main.querySelector(".jnt-digest")) {
        renderDigest();
      }
    } else if (action === "unsave" && job) {
      e.preventDefault();
      unsaveJob(id);
      renderSaved();
    }
  });

  modalClose.addEventListener("click", closeModal);
  modalBackdrop.addEventListener("click", closeModal);

  function openMenu(open) {
    nav.classList.toggle("is-open", open);
    navToggle.setAttribute("aria-expanded", open);
    navToggle.setAttribute("aria-label", open ? "Close menu" : "Open menu");
  }

  navToggle.addEventListener("click", function () {
    openMenu(navToggle.getAttribute("aria-expanded") !== "true");
  });

  document.querySelectorAll(".jnt-nav__link").forEach(function (link) {
    link.addEventListener("click", function () { openMenu(false); });
  });

  window.addEventListener("hashchange", function () { render(getRoute()); });

  render(getRoute());
})();
