# KodNest Premium Build System

Design system for KodNest. Calm, intentional, coherent. B2C product quality—no hackathon style.

## Philosophy

- **Calm, intentional, coherent, confident**
- No gradients, glassmorphism, neon, or animation noise
- Maximum 4 colors; spacing from a single scale; one consistent voice

## Usage

```html
<link rel="stylesheet" href="design-system/index.css" />
```

Use the class names and structure below. Do not introduce new spacing values or colors.

## Structure

| File | Purpose |
|------|--------|
| `tokens.css` | Colors, typography, spacing, radius, duration |
| `base.css` | Reset, body, headings, text blocks |
| `layout.css` | Top bar, context header, workspace, panel, proof footer |
| `components.css` | Buttons, badges, cards, inputs, prompt box, error/empty states |

## Global layout

Every page must follow:

1. **Top Bar** — Project name (left), Progress “Step X / Y” (center), Status badge (right)
2. **Context Header** — One large serif headline, one-line subtext, clear purpose
3. **Main** — **Primary workspace** (70%) + **Secondary panel** (30%)
4. **Proof Footer** — Checklist: UI Built, Logic Working, Test Passed, Deployed (each with proof input)

## Tokens (reference)

- **Background:** `#F7F6F3`
- **Text:** `#111111`
- **Accent:** `#8B0000`
- **Spacing:** `8px`, `16px`, `24px`, `40px`, `64px`
- **Transitions:** `180ms ease-in-out`
- **Border radius:** `6px`

## Components

- **Primary button:** `.kn-btn.kn-btn--primary` (solid deep red)
- **Secondary button:** `.kn-btn.kn-btn--secondary` (outlined)
- **Status badge:** `.kn-badge`, `.kn-badge--not-started`, `.kn-badge--in-progress`, `.kn-badge--shipped`
- **Card:** `.kn-card` (subtle border, no shadow)
- **Input / Textarea:** `.kn-input`, `.kn-textarea` (clean border, clear focus)
- **Panel:** `.kn-panel`, `.kn-prompt-box`, `.kn-prompt-box__actions`
- **Error state:** `.kn-state.kn-state--error` (what went wrong + how to fix)
- **Empty state:** `.kn-state.kn-state--empty` (next action, not dead)

No visual drift. One mind designed it.
